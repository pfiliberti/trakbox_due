/****************************************************************************************/
/*  					Sim51 Source Code : funcs3.c					    */
/****************************************************************************************/
/* You are free to modify,change and redistribute this source code of Sim51 only if you */
/* agree to share those changes and modifications with me and of course, you must also  */
/* mention my name as the original author of this program 'Sim51'. That's a very small  */
/* favour I am asking in return for more than 4000 free lines of hard written code.     */    
/****************************************************************************************/


#include"headers.c"
#include"vars.c"
#define printf printw
#define scanf scanw
//extern struct instruct;
//extern char tclk;
//extern struct instruct instructions[256];
int i=-16;
void cls();
void show_regs(char);
void rw_pc();
void rw_sp();
void rw_dp();
void rw_a();
void rw_b();
void rw_psw();
void rw_p0();
void rw_p1();
void rw_p2();
void rw_p3();
void rw_ip();
void rw_ie();
void rw_tm();
void rw_tc();
void rw_th0();
void rw_th1();
void rw_tl0();
void rw_tl1();
void rw_sc();
void rw_sb();
void rw_pcn();
void rw_em();
//extern void load_hex_file(char *);
			/* prototype declaration of */
void data_dump();       /* all required functions */
void code_dump(char*,char);
void display_help();
void input_hex();
void execute_code(char*,char);
void trace_code(char*,char);
void unassemble(char*,char);
void decode_and_simulate(int);
void proceed_execution();
//void vector_to_interrupt();

void display_shell()
{
 char ch,command[10],temp[10],temp2[10];
 int c,d,s,pos,hex_bkp;
 printf("\r-");
 refresh();
 fflush(stdin);
	gets(command);
	if(strlen(command)==0)
	  display_shell();
	else
	   {              //this stage removes all intervening spaces..
	      pos=0;
	      d=0;
	      do
		{
		 if(isspace(command[pos]))
		   pos++;
		 else
		    {
		      temp2[d]=command[pos];
		      if(command[pos]=='\0')
			   break;
		      pos++;
		      d++;
		    }
		}while(1);

 strcpy(command,temp2);

 if((command[0]=='c' && command[1]=='d')||(command[0]=='C' && command[1]=='D'))
    {
      if(strlen(command)==2)
	 code_dump("0",0);
      else
      {
	s=2;
	d=0;
      do
	{
	  temp[d]=command[s];
	  if(command[s]=='\0')
	    break;
	  d++;
	  s++;
	}while(1);
    code_dump(temp,1);

     }

}
else
       if((command[0]=='t')||(command[0]=='T'))
    {
      if(strlen(command)==1)
	 trace_code("0",0);   //no arg
      else
      {
	s=1;         // make this equal to no. of chars in the command
	d=0;
      do
	{
	  temp[d]=command[s];
	  if(command[s]=='\0')
	    break;
	  d++;
	  s++;
	}while(1);
    trace_code(temp,1);  //arg supplied

      }

  }


else
    if((command[0]=='u')||(command[0]=='U'))
    {
      if(strlen(command)==1)
	 unassemble("0",0);   //no arg
      else
      {
	s=1;         // make this equal to no. of chars in the command
	d=0;
      do
	{
	  temp[d]=command[s];
	  if(command[s]=='\0')
	    break;
	  d++;
	  s++;
	}while(1);
      unassemble(temp,1);  //arg supplied

      }

  }



else
    if((command[0]=='g')||(command[0]=='G'))
    {
      if(strlen(command)==1)
	 execute_code("0",0);   //no arg
      else
      {
	s=1;         // make this equal to no. of chars in the command
	d=0;
      do
	{
	  temp[d]=command[s];
	  if(command[s]=='\0')
	    break;
	  d++;
	  s++;
	}while(1);
      execute_code(temp,1);  //arg supplied

      }

  }






else
    if((command[0]=='b')||(command[0]=='B'))
    {
      if(strlen(command)==1)
       set_break_point(PC);  //no arg
       //	 set_break_point("0",0);   //no arg
      else
      {
	s=1;         // make this equal to no. of chars in the command
	d=0;
      do
	{
	  temp[d]=command[s];
	  if(command[s]=='\0')
	    break;
	  d++;
	  s++;
	}while(1);

   sscanf(temp,"%X",&hex_bkp);
   set_break_point(hex_bkp);  //arg supplied
   //   set_break_point(temp,1);  //arg supplied

      }

  }

/*else
if(!strcmp("lf",command))  {
printf("Enter hex filename to load:");
scanf("%s",temp);
load_hex_file(temp); 
}*/



else
   if(!strcmpi("lb",command))     /* show all breakpoints*/
   {
      int c=0;
      //for(c=0;c<bkp_no;c++)
      //while(break_points[c]!=-1 && c<=bkp_no)
      while(c<bkp_no)
       {
	 if(break_points[c] != -1)
	 {
		 printf("Breakpoint %d : PC=%X\n",c,break_points[c]);
	         refresh(); 
	 }
	 else
	    if(break_points[c] == -1)
	   {
		printf("Breakpoint %d : Removed\n",c);
		refresh(); 
	   }
	 c++;

       }
      display_shell();
      //show_regs('0');
   }
else 
if(!strcmp("lf",command))  {
				/*load a hex file...*/
	
	
	
	printf("Enter hex file name to load:");
	refresh();
	scanf("%s",temp);	



}
		
		


else
   if(!strcmpi("rb",command))     /* remove a particular breakpoint*/
   {
     char sbkp[6];
     int rbkp;
     printf("Remove Breakpoint no. [0-%d]?:",bkp_no-1);
     refresh();
     gets(sbkp);
     sscanf(sbkp,"%X",&rbkp);
     break_points[rbkp] = -1;
     printf("Breakpoint no. %d removed.\n",rbkp);
     refresh();
     display_shell();
   }

else
   if(!strcmpi("p",command))     /* proceed or step over a subroutine */
   {
      proceed_execution();
      //show_regs('0');
   }

else
   if(!strcmpi("v",command))     /* vector to a particular interrupt*/
   {
      vector_to_interrupt();

   }

else
   if(!strcmpi("r",command))     /* show all registers*/
   {
      show_regs('0');
   }
else
   if (!strcmpi("rpc",command))  /* read and write the program counter*/
     {
	rw_pc();
     }
else
   if (!strcmpi("rdp",command)) /*read and write the data pointer*/
     {
       rw_dp();
     }
else
   if(!strcmpi("rsp",command)) /*read and write the stack pointer*/
     {
       rw_sp();
     }


else
   if(!strcmpi("ra",command)) /*read and write the Accumulator...*/
     {
       rw_a();
     }


else
   if(!strcmpi("rb",command)) /*read and write the B register...*/
     {
       rw_b();
     }

else
   if(!strcmpi("rpsw",command)) /*read and write the PSW*/
     {
       rw_psw();
     }

else
   if(!strcmpi("rp0",command)) /*read and write port0*/
     {
       rw_p0();
     }

else
   if(!strcmpi("rp1",command)) /*read and write the port1*/
     {
       rw_p1();
     }

else
   if(!strcmpi("rp2",command)) /*read and write the port2*/
     {
       rw_p2();
     }


else
   if(!strcmpi("rp3",command)) /*read and write the port3*/
     {
       rw_p3();
     }

else
   if(!strcmpi("rip",command)) /*read and write the IP register...*/
     {
       rw_ip();
     }

else
   if(!strcmpi("rie",command)) /*read and write the interrupt enable reg...*/
     {
       rw_ie();
     }


else
   if(!strcmpi("rtm",command)) /*read and write the TMOD reg...*/
     {
       rw_tm();
     }


else
   if(!strcmpi("rtc",command)) /*read and write the TCON reg...*/
     {
       rw_tc();
     }


else
   if(!strcmpi("rth0",command)) /*read and write the TH0 reg...*/
     {
       rw_th0();
     }


else
   if(!strcmpi("rth1",command)) /*read and write the TH1 reg...*/
     {
       rw_th1();
     }


else
   if(!strcmpi("rtl0",command)) /*read and write the TL0 reg...*/
     {
       rw_tl0();
     }


else
   if(!strcmpi("rtl1",command)) /*read and write the TL1 reg...*/
     {
       rw_tl1();
     }


else
   if(!strcmpi("rsc",command)) /*read and write the SCON reg...*/
     {
       rw_sc();
     }


else
   if(!strcmpi("rsb",command)) /*read and write the SBUF reg...*/
     {
       rw_sb();
     }


else
   if(!strcmpi("rpcn",command)) /*read and write the PCON reg...*/
     {
       rw_pcn();
     }


else
   if(!strcmpi("em",command)) /*edit a location in RAM...*/
     {
       rw_em();
     }


else
   if(!strcmpi("cls",command)) /*edit a location in RAM...*/
     {
       cls();
     }


 // if (!strcmpi("u",command)) /*unassemble 128 bytes,starting from */
			    /*the current value of program counter*/
 //   {
  //    unassemble();  /*this function is defined in the decoder.c src file*/
  //  }
else
   if(!strcmpi("dd",command)) /* data dump of RAM area*/
    {
       data_dump();
    }

//  if (!strcmpi("cd",command)) /* code dump of ROM area*/
 /*   {
      code_dump(0);
    }  */
else
   if(!strcmpi("?",command))  /* a help menu of all possible commands*/
    {
      display_help();
    }
else
   if (!strcmpi("i",command)) /* prompt to take hex input from user*/
    {
       input_hex();
       display_shell();
    }
//else
 //  if (!strcmpi("g",command)) /* execute the code starting from current */
 //   {                       /* value of the program counter */
/*      execute_code();
      display_shell();
    }  */
//  if(!strcmpi("t",command)) /* trace the execution of code starting from */
  // {                        /* current value of the program counter */
  //   trace_code();
 //  }


else
   if(!strcmpi("q",command)) /*quiting cleanly....*/
    {
       exit(0);
    }

else
  {
   printf("Unrecognized Command!!\n");
   refresh();
   display_shell();
  }

}



}

void show_regs(char flag)
 {
   //printf("in show regs!!");
   //PSW=0xdd;
 /*  printf("%d",(PSW & 0x80)>>7);   */
   //flushall();


if(flag=='7')      //called via r...so no clk is reqd...
     {
   printf("A=%.2x  B=%.2x  PC=%.4x  PSW=%.2x  SP=%.2x  DPTR=%.4x\
   P0=%.2x  P1=%.2x  P2=%.2x  P3=%.2x      IP=%.2x  IE=%.2x TMOD=%.2x\
   TCON=%.2x  TH0=%.2x  TL0=%.2x  TH1=%.2x  TL1=%.2x  SCON=%.2x\n\
  SBUF=%.2x  PCON=%.2x                CY=%d  AC=%d  RS1=%d\
  RS0=%d  OV=%d  P=%d  CLK=%d",A&0x00ff,B&0x00ff,PC&0xffff,PSW&0x00ff,SP&0x00ff,DPH * 0x100 + DPL/*DPTR&0xffff*/,P0&0x00ff,P1&0x00ff,P2&0x00ff,P3&0x00ff,IP&0x00ff,\
   IE&0x00ff,TMOD&0x00ff,TCON&0x00ff,TH0&0x00ff,TL0&0x00ff,TH1&0x00ff,TL1&0x00ff,SCON&0x00ff,SBUF&0x00ff,PCON&0x00ff,((PSW & 0x80)>>7),\
   ((PSW & 0x40)>>6),((PSW & 0x10)>>4),((PSW & 0x08)>>3),((PSW & 0x04)>>2),\
   (PSW & 0x01),tclk );
   //((PSW & 0x10)>>4),((PSW & 0x08)>>3),((PSW & 0x04)>>2),(PSW & 0x01));
   printf("\n");
   refresh();
   disassemble_code(PC,1);

   if (go_flag==0)        // in case it is due to a 'go' command...
      display_shell();

      }

   if(flag=='1')       //called from trace...so clk is reqd..
   {
    printf("A=%.2x  B=%.2x  PC=%.4x  PSW=%.2x  SP=%.2x  DPTR=%.4x\
   P0=%.2x  P1=%.2x  P2=%.2x  P3=%.2x      IP=%.2x  IE=%.2x TMOD=%.2x\
   TCON=%.2x  TH0=%.2x  TL0=%.2x  TH1=%.2x  TL1=%.2x  SCON=%.2x\n\
SBUF=%.2x  PCON=%.2x                 CY=%d  AC=%d  RS1=%d\
  RS0=%d  OV=%d  P=%d  CLK=%d",A&0x00ff,B&0x00ff,PC&0xffff,PSW&0x00ff,SP&0x00ff,DPH * 0x100 + DPL/*DPTR&0xffff*/,P0&0x00ff,P1&0x00ff,P2&0x00ff,P3&0x00ff,IP&0x00ff,\
   IE&0x00ff,TMOD&0x00ff,TCON&0x00ff,TH0&0x00ff,TL0&0x00ff,TH1&0x00ff,TL1&0x00ff,SCON&0x00ff,SBUF&0x00ff,PCON&0x00ff,((PSW & 0x80)>>7),\
   ((PSW & 0x40)>>6),((PSW & 0x10)>>4),((PSW & 0x08)>>3),((PSW & 0x04)>>2),\
   (PSW & 0x01),tclk );
   //((PSW & 0x10)>>4),((PSW & 0x08)>>3),((PSW & 0x04)>>2),(PSW & 0x01));
   printf("\n");
   refresh();
   disassemble_code(PC,1);

   if (go_flag==0)        // in case it is due to a 'go' command...
      display_shell();
   }

   else if(flag=='0')      //called via r...so no clk is reqd...
      {

 /* printf("A=%.2x  B=%.2x  PC=%.4x  PSW=%.2x  SP=%.2x  DPTR=%.4x\
   P0=%.2x  P1=%.2x  P2=%.2x  P3=%.2x      IP=%.2x  IE=%.2x TMOD=%.2x\
   TCON=%.2x  TH0=%.2x  TL0=%.2x  TH1=%.2x  TL1=%.2x  SCON=%.2x\n\
SBUF=%.2x  PCON=%.2x                    CY=%d  AC=%d  RS1=%d\
  RS0=%d  OV=%d  P=%d ",A,B,PC,PSW,SP,DPH * 0x100 + DPL,P0,P1,P2,P3,IP,\
   IE,TMOD,TCON,TH0,TL0,TH1,TL1,SCON,SBUF,PCON,((PSW & 0x80)>>7),\
   ((PSW & 0x40)>>6),((PSW & 0x10)>>4),((PSW & 0x08)>>3),((PSW & 0x04)>>2),\
   (PSW & 0x01));  */

   printf("A=%.2x  B=%.2x  PC=%.4x  PSW=%.2x  SP=%.2x  DPTR=%.4x\
   P0=%.2x  P1=%.2x  P2=%.2x  P3=%.2x      IP=%.2x  IE=%.2x TMOD=%.2x\
   TCON=%.2x  TH0=%.2x  TL0=%.2x  TH1=%.2x  TL1=%.2x  SCON=%.2x\n\
SBUF=%.2x  PCON=%.2x                 CY=%d  AC=%d  RS1=%d\
  RS0=%d  OV=%d  P=%d ",A&0x00ff,B&0x00ff,PC&0xffff,PSW&0x00ff,SP&0x00ff,DPH * 0x100 + DPL,P0&0x00ff,P1&0x00ff,P2&0x00ff,P3&0x00ff,IP&0x00ff,\
   IE&0x00ff,TMOD&0x00ff,TCON&0x00ff,TH0&0x00ff,TL0&0x00ff,TH1&0x00ff,TL1&0x00ff,SCON&0x00ff,SBUF&0x00ff,PCON&0x00ff,((PSW & 0x80)>>7),\
   ((PSW & 0x40)>>6),((PSW & 0x10)>>4),((PSW & 0x08)>>3),((PSW & 0x04)>>2),\
   (PSW & 0x01) );

//   ((PSW & 0x10)>>4),((PSW & 0x08)>>3),((PSW & 0x04)>>2),(PSW & 0x01));
   printf("\n");
   refresh();
   disassemble_code(PC,1);

   display_shell();

      }






 }

void rw_pc()
 {
   //printf("inside rw_pc!!");
  printf("PC=%x\n:",PC);
  refresh();
  scanf("%x",&PC);
  display_shell();

 }

void rw_sp()
 {
  //printf("inside rw_sp!!");
  printf("SP=%x\n:",SP);
  refresh();
  scanf("%x",&SP);
  display_shell();


 }

void rw_dp()
 {
  unsigned int tempDPTR;
  //printf("inside rw_dp!!");
  printf("DPTR=%x\n:",DPH * 0x100 + DPL);
  refresh();
  scanf("%x",&tempDPTR);
  DPL = (unsigned char)(tempDPTR & 0x00ff);
  DPH = (unsigned char)( (tempDPTR>>8) & 0x00ff );
  display_shell();

 }


void rw_a()
 {
   //printf("inside rw_pc!!");
  printf("A=%x\n:",A);
  refresh();
  scanf("%x",&A);
  display_shell();

 }


void rw_b()
 {
   //printf("inside rw_pc!!");
  printf("B=%x\n:",B);
  refresh();
  scanf("%x",&B);
  display_shell();

 }

void rw_psw()
 {
   //printf("inside rw_pc!!");
  printf("PSW=%x\n:",PSW);
  refresh();
  scanf("%x",&PSW);
  display_shell();

 }


void rw_p0()
 {
   //printf("inside rw_pc!!");
  printf("P0=%x\n:",P0);
  refresh();
  scanf("%x",&P0);
  display_shell();

 }


void rw_p1()
 {
   //printf("inside rw_pc!!");
  printf("P1=%x\n:",P1);
  refresh();
  scanf("%x",&P1);
  display_shell();

 }


void rw_p2()
 {
   //printf("inside rw_pc!!");
  printf("P2=%x\n:",P2);
  scanf("%x",&P2);
  display_shell();

 }

void rw_p3()
 {
   //printf("inside rw_pc!!");
  printf("P3=%x\n:",P3);
  refresh();
  scanf("%x",&P3);
  display_shell();

 }

void rw_ie()
 {
   //printf("inside rw_pc!!");
  printf("IE=%x\n:",IE);
  refresh();
  scanf("%x",&IE);
  display_shell();

 }


void rw_ip()
 {
   //printf("inside rw_pc!!");
  printf("IP=%x\n:",IP);
  refresh();
  scanf("%x",&IP);
  display_shell();

 }

void rw_tm()
 {
   //printf("inside rw_pc!!");
  printf("TMOD=%x\n:",TMOD);
  refresh();
  scanf("%x",&TMOD);
  display_shell();

 }

void rw_tc()
 {
   //printf("inside rw_pc!!");
  printf("TCON=%x\n:",TCON);
  refresh();
  scanf("%x",&TCON);
  display_shell();

 }


void rw_th0()
 {
   //printf("inside rw_pc!!");
  printf("TH0=%x\n:",TH0);
  refresh();
  scanf("%x",&TH0);
  display_shell();

 }


void rw_th1()
 {
   //printf("inside rw_pc!!");
  printf("TH1=%x\n:",TH1);
  refresh();
  scanf("%x",&TH1);
  display_shell();

 }

void rw_tl0()
 {
   //printf("inside rw_pc!!");
  printf("TL0=%x\n:",TL0);
  refresh();
  scanf("%x",&TL0);
  display_shell();

 }

void rw_tl1()
 {
   //printf("inside rw_pc!!");
  printf("TL1=%x\n:",TL1);
  refresh();
  scanf("%x",&TL1);
  display_shell();

 }


void rw_sc()
 {
   //printf("inside rw_pc!!");
  printf("SCON=%x\n:",SCON);
  refresh();
  scanf("%x",&SCON);
  display_shell();

 }


void rw_sb()
 {
   //printf("inside rw_pc!!");
  printf("SBUF=%x\n:",SBUF);
  refresh();
  scanf("%x",&SBUF);
  display_shell();

 }


void rw_pcn()
 {
   //printf("inside rw_pc!!");
  printf("PCON=%x\n:",PCON);
  refresh();
  scanf("%x",&PCON);
  display_shell();

 }


void rw_em()
 {
   //printf("inside rw_pc!!");
  unsigned int addr;
  unsigned int data;
  printf("Enter address of location to edit:");
  refresh();
  scanf("%X",&addr);
  printf("RAM[%.4X]=%.2X\n:",addr,RAM[addr]);
  scanf("%X",&data);
  RAM[addr]=(unsigned char)data;
  display_shell();

 }

void cls()
 {
   clear(); 
   //clrscr();
   display_shell();
 }


void data_dump()
 {
   static int k=0;
   static int kount=0;
   int i=0;
   //printf("inside data_dump()!!");
  /* for(i=0;i<128;i++)
	RAM[i]=i;     // just testing RAM...
    RAM[124]=0xee;
    RAM[0]=0xff;   */
   for(i=0;i<127;i+=16)
     {
       //kount++;
       printf("%.4x:  ",i);
       refresh();
  for(;k<16+kount*16;k++)
	 {

	    if((k%8)==0 && ((k%16)))
	      {
		printf(" -  ");
	      }
	    printf("%.2x ",RAM[k]);
	 }
       printf("\n");
     refresh();
  if(k==128)
	{
	  kount=0;
	  k=0;
	  //i=0;
	}
     else
	  kount++;

     }

 display_shell();

 }

void code_dump(char *n,char flag)
 {

   int temp,start;
   static int count=0,t=0;
   int j;
sscanf(n,"%x",&start);
if(start==0 && flag==0)     /*flag=0 -> no arg.*/
    ;
    //i=-16;                  /*flag=1 -> arg. supplied*/
if(start==0 && flag==1)
    i=-16;

temp=start;
  start=(start/16)*16;
if(start==0 && (temp<=15) && (flag==1))
	 i=-16;
if(!(start==0))
      i=start-16;
   i+=16;
   for(;i<0xfff;i++)
     {
      if((i%16)==0)
	 {
	   printf("%.4x:  ",i);
	   refresh();
  	   t++;
	   //count++;
	   //for(j=i;j<=(0xf+0x10*(count));j++)
	    for(j=i;j<=(0xf+i);j++)
	     {
	       if((j%8)==0 && ((j%16)))
		    printf(" -  ");
	       if(j>=temp)
		  printf("%.2x ",ROM[j]);
	       else
		  printf("   ");
		  refresh();
  
	     }

	   printf("\n");
	   refresh();
  	   if((t%8)==0)
	     {
	       display_shell();
	     }

	  count++;
	  }

	 }
display_shell();

 }


void display_help()
 {
   int chr,nl=0;
   FILE *fp;
   clear();
   //clrscr();
   if ( (fp=fopen("sim51.hlp","r"))==NULL)
     {
       printf("Help file not found!!\n\n");
       refresh();
     }
   else
      {
	while( (chr=fgetc(fp))!=EOF )
	  {
	    if(chr=='\n')
	      nl++;

	    if( (nl%24)==0 && nl!=0  )
	      {
		printf("\nPress any key...");
		refresh();
  		getch();
		printf("\r                 "); //to remove the extra line
		refresh();
  		//clrscr();
		nl++;
		//nl=1;
		fflush(stdin);
	      }
	    fputc(chr,stdout);


	  }

      }




  display_shell();

   //printf("inside display_help()!!");
 }

void input_hex()
 {
   //printf("inside input_hex()!!");
   int loc;
   char *s;
   printf(":");
   refresh();
   scanf("%x",&loc);
   fflush(stdin);
   for(;;loc++)
    {
      printf("%.4x: ",loc);
      refresh();
      gets(s);
      if(strlen(s)==0)
	break;
      else
	 sscanf(s,"%x",&ROM[loc]);

    }

 display_shell();
 fflush(stdin);
 }

void execute_code(char *n,char flag)
 {
   int count=0,ins=-1,start;  //ins is set to -1 to distinguish between
   char str[6];               // no arg. and intentional 0 arg...
   go_flag=1;
   sscanf(n,"%x",&start);

   if(flag==0)   //means no arg, has been given...
       {
	 printf("Execute how many instructions[default=5]?:\n");
	 refresh();
  	 gets(str);
	 sscanf(str,"%x",&ins);
	 if(ins==-1)
	   ins = 5;       //setting default value...

       }

   else
       if(flag==1)    //means arg has been supplied...
	 ins = start;
   //do



    while (count<ins)
      {
	     count++;
    //	if(  (check_for_bkpoint(PC))==1  && (ins==1)  )  //means no bkpoint...
   //	  {
	     //trace_code(itoa(PC,str,16),1);  // arg supplied....
	     printf("\n");
       //	  }	//printf("hello\n");
	//count++;
    //  else
     //	 if(  (check_for_bkpoint(PC))==1  && ( ins>1 )     )  //  means bkpoint...
      //	  {
      //	     printf("Stopped execution at break point PC=%X\n",PC);
	 	     refresh();

                     //display_shell();

       //	  }


      } //while (count<ins);
    go_flag=0;
    //strcpy(command,"");
    display_shell();
   //printf("inside execute_code()!!");
 }


/*void proceed_execution()
 {
    unsigned int initPC,finalPC;
    char str[6];
    //if(instructions[ROM[PC]].nobytes==1)
       finalPC = PC + instructions[ROM[PC]].nobytes;
       go_flag=1;
       while(PC != finalPC)
	 {
	   //go_flag=1;
	   trace_code(itoa(PC,str,16),1);  // arg supplied....
	   printf("\n");
	   refresh();
  
	 }
      go_flag=0;
      display_shell();
 }     */

void trace_code(char *n,char flag)
 {
   int temp,start;
   char foo_flag;
   sscanf(n,"%x",&start);
   if(flag==0)     //flag=0 -> no arg.,start tracing from
     {                             //current value of PC
	if( (check_for_bkpoint(PC))==1 && go_flag==1)   //means bkpoint...
	   {
	    printf("Stopped execution at break point PC=%X\n",PC);
	    refresh();
  
	    display_shell();
	   }

	else
	   //if( (check_for_bkpoint(PC))==0)   //means no bkpoint...*/
	       decode_and_simulate(PC);
     }
   else
     {
			//else flag=1 -> arg. is starting point of trace*/

      foo_flag = check_for_bkpoint(start);

      //if( (check_for_bkpoint(start))==1 && go_flag==1)   //means bkpoint...
	  if( (foo_flag == 1)  &&  (go_flag==1)  )
	   {
	     printf("Stopped execution at break point PC=%X\n",PC);
	     refresh();
  	     go_flag = 0;   //resetting go_flag again for next cycle...
	     display_shell();
	   }


	else
	   //if( (check_for_bkpoint(start))==0  && flag==1)   //means no bkpoint... */
	      decode_and_simulate(start);

     }





  /*int temp,start;
   static int count=0,t=0;
   int j;
sscanf(n,"%x",&start);
if(start==0 && flag==1)     //flag=1 -> no arg.
    i=-16;                  //flag=0 -> arg. supplied
temp=start;
  start=(start/16)*16;
if(start==0 && (temp<=15))
	 i=-16;
if(!(start==0))
      i=start-16;
   i+=16;
   for(;i<0xfff;i++)
     {
      if((i%16)==0)
	 {
	   printf("%.4x:  ",i);
	   refresh();
  	   t++;
	   //count++;
	   //for(j=i;j<=(0xf+0x10*(count));j++)
	    for(j=i;j<=(0xf+i);j++)
	     {
	       if((j%8)==0 && ((j%16)))
		    printf(" -  ");
	       if(j>=temp)
		  {
 			printf("%.2x ",ROM[j]);
			refresh();
  		  }
	       else
		  {
                    printf("   ");
			refresh();
  		  }

	     }

	   printf("\n");
	   refresh();
 
           if((t%8)==0)
	     {
	       display_shell();
	     }

	  count++;
	  }

	 }   */
if(go_flag==0)
  display_shell();



   //printf("inside trace_code()!!");
 }

