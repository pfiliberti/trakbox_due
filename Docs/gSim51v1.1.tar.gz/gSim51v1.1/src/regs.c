/****************************************************************************************/
/*  					Sim51 Source Code : regs.c					    */
/****************************************************************************************/
/* You are free to modify,change and redistribute this source code of Sim51 only if you */
/* agree to share those changes and modifications with me and of course, you must also  */ 
/* mention my name as the original author of this program 'Sim51'. That's a very small  */
/* favour I am asking in return for more than 4000 free lines of hard written code.     */    
/****************************************************************************************/




/* this file contains all the registers of the 8051 uc.all of them
will be subsequently used as external variables.........*/
/*struct instruct
 {
   int hex_code;
   const char *mnemonic;
   int nobytes;
   int clock;
   int noperands;
   void (*ins_func_ptr)(int);
}instructions[]={
		    {0,"NOP",4,0,nop_isr},
		    {1,"ADD A",4,1,nop_isr}
		};   */
   //extern struct instruct instructions[];
   long  break_points[10]={-1};
   int bkp_no=0;
   char go_flag=0;
   char tclk;
   unsigned short int UC=0;   /* this is required for the disassembler... and 'short int' is used coz it is of 2 bytes only...*/
   //unsigned char *RAM; /* ram and SFRs for the uc*/  //changed to int on 10th sept, 2002..
   unsigned char *ROM; /* rom for the uc to be allocated dynamically...*/
   unsigned char *XDATA;
   //

   unsigned char RAM[256]={0}; /* ram and SFRs for the uc*/  //changed to int on 10th sept, 2002..
   //unsigned char ROM[4096]={0}; /* rom for the uc*/
   //unsigned char A=0; /*accumulator reg*/
   //unsigned char B=0; /* B register */
   int PC=0; /* program counter*/
   //int A=0;
   //int SP=7; /*stack pointer*/
   //unsigned char  PSW=0; /* program status word or flags register*/
   //int DPTR=0; /* data pointer */

   //unsigned char  DPL=0; /* low order data pointer*/
   //unsigned char  DPH=0; /*high order data pointer*/
   //unsigned char  P0=0; /*port 0*/
   //unsigned char  P1=0; /*port 1*/
   //unsigned char  P2=0; /*port 2*/
   //unsigned char  P3=0; /*port 3*/
   //unsigned char  IP=0; /*interrupt priority enable*/
   //unsigned char  IE=0; /*interrupt enable control*/
   //unsigned char  TMOD=0;/*timer/counter mode control*/
   //unsigned char  TCON=0;/*timer/counter control*/
   //unsigned char  TH0=0;/*timer/counter 0 high byte*/
   //unsigned char  TL0=0;/*timer/counter 0 low byte*/
   //unsigned char  TH1=0;/*timer/counter 1 high byte*/
   //unsigned char  TL1=0;/*timer/counter 1 low byte*/
   //unsigned char  SCON=0;/*serial control*/
   //unsigned char  SBUF=0;/*serial data buffer*/
   //unsigned char  PCON=0;/*power control*/



   //printf("from registers!!");  /*to be used for debugging...*/
