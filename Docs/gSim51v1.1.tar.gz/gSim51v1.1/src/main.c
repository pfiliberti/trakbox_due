/****************************************************************************************/
/*  					Sim51 Source Code : main.c					    */
/****************************************************************************************/
/* You are free to modify,change and redistribute this source code of Sim51 only if you */
/* agree to share those changes and modifications with me and of course, you must also  */ 
/* mention my name as the original author of this program 'Sim51'. That's a very small  */
/* favour I am asking in return for more than 4000 free lines of hard written code.     */    
/****************************************************************************************/


#include"headers.c"
#include"vars.c"  /* including this file includes the  */
#include<ncurses.h>
#define printf printw
#define scanf scanw
void load_hex_file(char *);


WINDOW *win;
//#define sscanf sscanw

/* 8051 Register variables globally*/
//void display_prompt();
//extern struct instruct;
int main()
  {
    unsigned char format,mode,*hex_file,*line,c;//,hex_val;
    unsigned int addr,hex_val,i;
    char inp_line[80]={0},str[5]={0};
    FILE *fp;
    //clrscr();
    //RAM = (int *)malloc(256 * sizeof(unsigned char));
    ROM = (unsigned char *)malloc(64 * 1024 * sizeof(unsigned char));
    memset((unsigned char*)ROM,0x00,0x1000);

    XDATA  = (unsigned char *)malloc(64 * 1024 * sizeof(unsigned char));
    memset((unsigned char*)XDATA,0x00,0x1000);





    /*A++;
    printf("\n\rhello, world!");
    getch();
    printf("%x ",A);*/
    /*printf("%x ",PSW);
    printf("%x ",PC);
    getch();*/
    // printf("from main!!"); /*for debugging*/

    //SP=7;  //not needed anymore...//initialising the stack pointer to 7
    initscr();
    scrollok(stdscr,TRUE);
    //win=newwin(20,40,10,20);
    //wborder(win,0,0,0,0,0,0,0,0);
    printf("\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\t\t\t             gSim51");
    printf("\n\r\t\t           8051uc Simulator on Linux");
    //printf("\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\t\t\t\t8051uc Simulator");
    printf("\n\r\t\t\tDeveloped by: Seemanta Dutta");
    printf("\n\r\t\t\tGuided by : Dr. A.K. Gogoi(IITG)");
//    textcolor(7+BLINK);
    //cprintf("\n\r\r\n\r\r                               Press any key...");
  //  move(33,14);
    //addch(A_BLINK);
    attrset(A_BLINK);
    waddstr(stdscr,"\n\r\t\t\t\tPress Any Key...");
    attrset(0);
    refresh();
    //box(win,1,2);
    //waddstr(win,"sdjkfklflkkdfjklfjlfjkldjfkdlfjdkljkfljdkldjfklfjdklfdj\n");
    wrefresh(stdscr);
//vline('|',20);
//refresh();
    //printf("\n\r\t\t\t\tPress any key...");
    //printf("%d",getcolor());
   // textcolor(7);


    move(8,20);addch(ACS_ULCORNER);
     for(c=20;c<58;c++)
	 addch(ACS_HLINE);
    move(8,58);addch(ACS_URCORNER);
      //printf("g");
      for(c=9;c<=14;c++)
	{
	  move(c,58);
	  addch(ACS_VLINE);
	}
    move(14,58);addch(ACS_LRCORNER);
       for(c=57;c>=21;c--)
	 {
	   move(14,c);
	   addch(ACS_HLINE);
	 }


    move(14,20);addch(ACS_LLCORNER);
	for(c=13;c>=9;c--)
	  {
	    move(c,20);
	    addch(ACS_VLINE);
	  }

    move(13,49);


    getch();
    //textcolor(WHITE);
//do
//{

    clear();
	//clrscr();

    printf("Starting Simulator in Console Mode...\n\n");
    printf("Type \'?\' for a summary of commands\n");
    
    /*printf("\n\r\n\r\n\r\t\t\tEnter the mode[C(onsole)/F(ile)]:");
    refresh();
    scanf("%c",&mode);
    strcmp("less","less"); */
    //if(toupper(mode)=='C')
      //{
	 //printf("\n\r\n\r\t\t\tConsole mode!!");
	 for(i=0;i<256;i++)   // ad hoc procedure to set all RAM
		     RAM[i]=0;     // locations to zero before start...
		  RAM[0x81]=7;  // in case of loadparm module...call it
				//only after this RAM is set...as
				//some registers may have to be changed..
			      // better find out a new way out of this...
			         //  soon!!!   -seemanta..  ;)
	 display_shell();
      //}

    //  else if(toupper(mode)=='F')
     //  {

   //	printf("\n\r\n\r\t\t      Enter file format[(R)aw/(H)ex]:");
//	refresh();
//	fflush(stdin);
//	    scanf("%c",&format);

//	if( toupper(format)=='H')
//	  {
	         refresh();
     getch();
     fflush(stdin);

    getch();
    return 0;
  }

void load_hex_file(char *hex_file)
{
		  
    unsigned char format,mode,*line,c;//,hex_val;
    unsigned int addr,hex_val;
    char inp_line[80]={0},str[5]={0};
    FILE *fp;
    int org=0,code,temp,count,type,code_byte,cksum_byte,chr,i=0;//,j=0;

	if((fp=fopen(hex_file,"r"))==NULL)
	  {
	    printf("\nError: File doesn't exist!!\n");
	    refresh();		  
	    flushinp();
	    fflush(stdin);
	    display_shell();
	  }

	else
	  {
	     while(  (fgets(inp_line,80,fp)))// || chr!='\n\r')
	      {
	     sscanf(inp_line,":%2X%4X%2X",&count,&addr,&type);

		for(i=0;i<=2*(count-1);i+=2)
		    {
		     str[0]=inp_line[9+i];
		     str[1]=inp_line[9+i+1];
		     str[2]='\0';
		     sscanf(str,"%2X",&hex_val);

		     ROM[addr]=hex_val;
		     addr++;
		      refresh();
		    }
	       }
	printf("\nHex file \'%s\' loaded!!\n",hex_file);
	refresh();
	     
	}

		fclose(fp);

		  for(i=0;i<256;i++)   // ad hoc procedure to set all RAM
		     RAM[i]=0;     // locations to zero before start...
		  RAM[0x81]=7;  // in case of loadparm module...call it
				//only after this RAM is set...as
				//some registers may have to be changed..
			      // better find out a new way out of this...
			      //  soon!!!   -seemanta..  ;)

		display_shell();

}


