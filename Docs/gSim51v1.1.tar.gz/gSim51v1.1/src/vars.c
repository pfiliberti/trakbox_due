/****************************************************************************************/
/*  					Sim51 Source Code : vars.c					    */
/****************************************************************************************/
/* You are free to modify,change and redistribute this source code of Sim51 only if you */
/* agree to share those changes and modifications with me and of course, you must also  */ 
/* mention my name as the original author of this program 'Sim51'. That's a very small  */
/* favour I am asking in return for more than 4000 free lines of hard written code.     */    
/****************************************************************************************/


#define A RAM[0XE0]
#define B RAM[0xF0]
#define PSW RAM[0XD0]
#define SP RAM[0X81]
#define DPL RAM[0X82]
#define DPH RAM[0X83]
#define P0 RAM[0X80]
#define P1 RAM[0X90]
#define P2 RAM[0XA0]
#define P3 RAM[0XB0]
#define IP RAM[0XB8]
#define IE RAM[0XA8]
#define TMOD RAM[0X89]
#define TCON RAM[0X88]
#define TH0 RAM[0X8C]
#define TL0 RAM[0X8A]
#define TH1 RAM[0X8D]
#define TL1 RAM[0X8B]
#define SCON RAM[0X98]
#define SBUF RAM[0X99]
#define PCON RAM[0X87]
   extern char go_flag;  //0 means 'go' command has not been given...

   extern long break_points[10];
   extern int bkp_no;
   //SP=7;
   extern char tclk;
   extern unsigned short int UC;  //because 'int' is of 4 bytes and 'short int' is of 2 bytes...
   //extern unsigned char *RAM;
   extern unsigned char *ROM;
   extern unsigned char *XDATA;
   extern unsigned char RAM[256];
   //extern unsigned char ROM[4096];
   //extern unsigned char  A; /*accumulator reg*/
   //extern unsigned char  B; /* B register */
   extern int PC; /* prgram counter*/
   //extern int SP; /* satck pointer*/
   //extern unsigned char  PSW; /* program status word or flags register*/
   //extern int DPTR; /* data pointer */
   //extern unsigned char  DPL; /* low order data pointer*/
   //extern unsigned char  DPH; /*high order data pointer*/
   //extern unsigned char  P0; /*port 0*/
   //extern unsigned char  P1; /*port 1*/
   //extern unsigned char  P2; /*port 2*/
   //extern unsigned char  P3; /*port 3*/
   //extern unsigned char  IP; /*interrupt priority enable*/
   //extern unsigned char  IE; /*interrupt enable control*/
   //extern unsigned char  TMOD;/*timer/counter mode control*/
   //extern unsigned char  TCON;/*timer/counter control*/
   //extern unsigned char  TH0;/*timer/counter 0 high byte*/
   //extern unsigned char  TL0;/*timer/counter 0 low byte*/
   //extern unsigned char  TH1;/*timer/counter 1 high byte*/
   //extern unsigned char  TL1;/*timer/counter 1 low byte*/
   //extern unsigned char  SCON;/*serial control*/
   //extern unsigned char  SBUF;/*serial data buffer*/
   //extern unsigned char  PCON;/*power control*/
 


