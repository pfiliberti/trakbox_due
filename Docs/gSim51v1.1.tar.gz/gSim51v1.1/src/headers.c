/****************************************************************************************/
/*  					Sim51 Source Code : Headers.c					    */
/****************************************************************************************/
/* You are free to modify,change and redistribute this source code of Sim51 only if you */
/* agree to share those changes and modifications with me and of course, you must also  */ 
/* mention my name as the original author of this program 'Sim51'. That's a very small  */
/* favour I am asking in return for more than 4000 free lines of hard written code.     */    
/****************************************************************************************/


#include<stdio.h>
//#include<conio.h>
#include<stdlib.h>
//#include<dos.h>
#include<time.h>
//#include<process.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
#include<ncurses.h>
//#include<graphics.h>
