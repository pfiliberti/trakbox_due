************************gSim51 Readme**************************

gSim51 is an open source,easy to use, text based simulator for the 8051
microcontroller running on the Linux Platform. It is actually a Linux port of 
the DOS based simulator, 'Sim51'.
It has been designed to match the DOS 'Debug' program so that those who are
already acquainted with 'Debug' can easily learn using gSim51 within a very short time. 
Following the unix tradition of simplicity and efficiency, all the commands of
gSim51 are short and may seem difficult to remember at first. But in the end these short, terse commands prove to be very efficient in doing the job of simulating your code.

The following is a list of the SALIENT FEATURES of gSim51.

1. gSim51 is fully Intel Hex file compatible. So you can now use any assembler 
of your choice to generate the equivalent hex file and run it in gSim51.

2. The simulator can be made to run in its 'Console' mode, wherein it behaves almost like a microcontroller kit where you can directly punch in the preassembled hex code of your program.

3. gSim51 incorporates full debugging facilities like setting,removing
breakpoints as well as 'step into' and 'step over' features. In this regard,
therefore, gSim51 can also be thought of as an efficient debugger.

4. Almost all of gSim51's commands resemble that of DOS debug, hence use by 'debug' users is facilitated greatly.

5. The commands of gSim51 provide great flexibility during simulation. For example the 'r' command without any parameters shows all 8051 registers. However the same 'r' command when followed by any register name enables editing of that register. Same goes for other commands as well.

6. gSim51 has provisions for simulating 8051 interrupts during execution, which is another valuable asset.

7. A short, but comprehensible online command reference is always at your disposal for refering to any command during simulation.

Beginners are advised to go through the offline documentation and also the short tutorial, before trying out the simulator. A few test programs in Hex format are given to try out the tutorial.


******************Still to come in gSim51 *****************************
At present gSim51 supports only 4K of code. Whenever time permits,i am working on it to make it full 64K compatible. 
gSim51 also does not support Serial port and timers at present.
These shortcomings will be fixed promptly as soon as possible. Since it  does
not support 64k code, instructions that use external code are not implemented
in gSim51 at present. These instructions are:

					MOVX A,@DPTR
					MOVX A,@R0
					MOVX A,@R1
					MOVX @DPTR,A
					MOVX @R0,A
					MOVX @R1,A


**********************************************************************

Although there are a few shortcomings in gSim51, it is hoped that they will
not severely impede the utility of the simulator. Please note that gSim51 is a
product of my interest in microcontrollers and I have written it completely in
my free time. Hence the aforementioned developments may take sometime before gSim51 is fully ready with them.
( I have my exams right now!!). 
In the meantime alL its users are encouraged to change,modify and redistribute
the source code of gSim51. The source code of gSim51 is in the 'src' folder of
this distribution. All comments, suggestions and feedback are welcome. You can
mail them to me at						
			seemanta_18@yahoo.com

In case of redistributions just do me a small favour - mention my name in the source as the original developer and also inform me about it with details of all changes made.
This is very important- As the original author of gSim51, i have a right to
get all the subsequent modifications of my source code, since I am releasing
gSim51 under GPL. Besides, I shall also be maintaining my own distribution of
gSim51 which will be kept updated at all times.


And now about BUGS  \�/
		    /;\	.....

Although i have tried my best to eliminate all bugs from gSim51( and by that i mean to say that almost three fourths of development time was spent in fixing bugs), bugs do creep in. In case you observe any sort of bug, however small or insignificant it may be, please report it to me along with a list of parameters which reproduce the bug, and a written description of the bug itself. You may think of it as a request.In case there might be some error in the way some instruction is behaving.(With 255 instructions, that may happen quite naturally) These kinds of bugs are most important and it is on you users that i depend on for a quick removal of these bugs. So please help me eliminate these bugs. In case u are fortunate enough to have eliminated the bug, i shall be obliged if u could share that information with me.
my email as mentioned earlier is  
				   seemanta_18@yahoo.com


Before concluding, i would like to thank Dr. A.K. Gogoi, HOD of ECE Dept.,IITG for his guidance in making this simulator for 8051 possible to make.
thank you very much sir!

Happy Simulation!!

Seemanta Dutta
Final Year B.E.
Electronics and Communication Engineering
Hostel 5, Room No. 101
MNIT Jaipur, Rajasthan
INDIA
